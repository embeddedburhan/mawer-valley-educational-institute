MAWER VALLEY EDUCATIONAL INSTITUTE WEBSITE

Included:
- index.html: responsive school website
- assets/school-logo.jpg: supplied school emblem
- assets/admissions-2026-27.jpg: supplied admissions poster
- assets/results-announcement.jpg: supplied results notice poster

Details added:
- Principal: Sajad Mohammad Kar
- Phone/WhatsApp: +91 97971 54180
- Admissions poster states Pre-Nursery to Class 8 for session 2026–2027.

Important:
- The results poster has no visible date; parents should confirm current result/marks-card arrangements with the school office.
- Replace sample stock photos with actual campus/classroom photographs when available.
- Confirm the admission session and class availability before keeping the poster live.
- Keep the assets folder beside index.html when uploading to GitHub Pages/Netlify.
- The enquiry form opens WhatsApp with a pre-filled message; the user must press Send in WhatsApp.

To preview, open index.html in a browser.
